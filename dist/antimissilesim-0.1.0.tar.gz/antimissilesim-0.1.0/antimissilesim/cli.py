# antimissilesim/cli.py
import argparse
from .kalman import main as kalman_main  

def main():
    parser = argparse.ArgumentParser(description="Run Antimissile Simulation")
    parser.add_argument("--mode", type=str, choices=["kalman", "mcts", "pomdp"], default="kalman", help="Select mode")
    args = parser.parse_args()

    if args.mode == "kalman":
        kalman_main()  # Call your Kalman filter function
    elif args.mode == "mcts":
        from .mcts import main as mcts_main
        mcts_main()
    elif args.mode == "pomdp":
        from .pomdp import main as pomdp_main
        pomdp_main()

if __name__ == "__main__":
    main()

