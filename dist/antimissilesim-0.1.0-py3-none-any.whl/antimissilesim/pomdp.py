import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation
import random

# Simulation Constants
number_of_simulations = 1000
max_steps = 10000
show_plots = False

missile_reached_goal = 0
missile_intercepted = 0


# Define the missile environment
class MissileEnv:
    def __init__(self, bounds=(1000, 1000, 1000), velocity=100):
        self.bounds = bounds
        self.velocity = velocity  # Speed in units per second
        self.start = np.array([0.0, 0.0, 0.0])
        self.goal = np.array([random.uniform(800, 1000), 
                               random.uniform(0, bounds[1]), 
                               random.uniform(0, bounds[2])])
        self.position = np.copy(self.start)
        self.path = [self.position]
        self.velocity_vector = np.array([0, 0, 0])  # Tracks movement direction
        self.reached_goal = False  # Track if goal is reached

    def reset(self):
        self.position = np.copy(self.start)
        self.path = [self.position]
        self.reached_goal = False

    def step(self, action):
        # self.position += self.velocity_vector * self.velocity #* 0.05  # Adjust step size
        self.velocity_vector = 0.8 * self.velocity_vector + 0.2 * action
        self.position += self.velocity_vector * self.velocity * 0.2  # Adjust step size

        self.path.append(self.position.copy())

        if np.linalg.norm(self.position - self.goal) < 10:
            self.reached_goal = True

    def get_state(self):
        return self.position.copy()
    
    def is_goal_reached(self):
        return self.reached_goal

    def get_possible_actions(self):
        # Define possible movement directions in 3D
        return [
            np.array([1, 0, 0]), np.array([-1, 0, 0]),
            np.array([0, 1, 0]), np.array([0, -1, 0]),
            np.array([0, 0, 1]), np.array([0, 0, -1]),
            np.array([1, 1, 0]), np.array([-1, -1, 0]),
            np.array([1, 0, 1]), np.array([-1, 0, -1]),
            np.array([0, 1, 1]), np.array([0, -1, -1])
        ]

# Define the POMDP Planner
class POMDPPlanner:
    def __init__(self, env, antimissile, belief_particles=100):
        self.env = env
        self.antimissile = antimissile
        self.belief_particles = belief_particles
        self.belief = [env.get_state() + np.random.normal(0, 2, 3) for _ in range(belief_particles)]  
        # self.belief = [env.get_state() for _ in range(belief_particles)]  


    def update_belief(self, observation):
        self.belief = [obs + np.random.normal(0, 3, 3) for obs in self.belief]  # Example update rule
        # self.belief = [obs for obs in self.belief]  # Example update rule

    def closer_to_goal(self, state, next_state):
        return np.linalg.norm(next_state - self.env.goal) < np.linalg.norm(state - self.env.goal)
    
    def closer_to_antimissile(self, state, next_state):
        return np.linalg.norm(next_state - self.antimissile.get_state()) < np.linalg.norm(state - self.antimissile.get_state())

    def reward(self, state, action, next_state, goal):
        # Compute raw distance changes
        goal_distance_change = np.linalg.norm(state - goal) - np.linalg.norm(next_state - goal)
        antimissile_distance_change = np.linalg.norm(next_state - self.antimissile.get_state()) - np.linalg.norm(state - self.antimissile.get_state())

        # Normalize changes to [0, 1]
        max_goal_change = np.linalg.norm(state - goal)  # Max possible change for goal
        max_antimissile_change = np.linalg.norm(state - self.antimissile.get_state())  # Max possible change for antimissile

        goal_distance_change_norm = goal_distance_change / max_goal_change if max_goal_change != 0 else 0
        antimissile_distance_change_norm = antimissile_distance_change / max_antimissile_change if max_antimissile_change != 0 else 0

        # Weighted reward components
        reward = 0.7 * goal_distance_change_norm + 0.3 * antimissile_distance_change_norm

        # print(f"Goal Distance Change: {goal_distance_change}, Normalized: {goal_distance_change_norm}")
        # print(f"Antimissile Distance Change: {antimissile_distance_change}, Normalized: {antimissile_distance_change_norm}")

        return reward

    # Non-scaled reward function, left in because it created interesting inital behavior 
    # def reward(self, state, action, next_state, goal):
    #     # Distance changes
    #     goal_distance_change = np.linalg.norm(state - goal) - np.linalg.norm(next_state - goal)
    #     antimissile_distance_change = np.linalg.norm(next_state - self.antimissile.get_state()) - np.linalg.norm(state - self.antimissile.get_state())

    #     print(f"Goal Distance Change: {goal_distance_change}, Antimissile Distance Change: {antimissile_distance_change}")

    #     # Reward for getting closer to goal
    #     reward = 5 * goal_distance_change  

    #     # Reward for staying away from the anti-missile
    #     reward += 2 * antimissile_distance_change  

    #     return reward


    def search(self):
        best_action = None
        best_reward = float('-inf')

        for action in self.env.get_possible_actions():
            next_state = self.env.get_state() + action * self.env.velocity #* 0.05  # Simulate next state
            action_reward = self.reward(self.env.get_state(), action, next_state, self.env.goal)

            if action_reward > best_reward:
                best_reward = action_reward
                best_action = action

        # print(f"Selected action {best_action} with reward {best_reward}")
        return best_action

# Define the anti-missile system with proportional navigation
class AntiMissile:
    def __init__(self, target, bounds=(1000, 1000, 1000), velocity=105, navigation_gain=3.0):
        self.velocity = velocity  # Faster than the missile
        self.position = np.array([random.uniform(800, 1000), random.uniform(0, bounds[1]), random.uniform(0, bounds[2])])
        self.target = target
        self.path = [self.position]
        self.intercepted = False
        self.intercept_point = None
        self.navigation_gain = navigation_gain  # Gain factor for proportional navigation
        
    def proportional_navigation(self):
        missile_pos = self.target.get_state()
        los_vector = missile_pos - self.position
        los_distance = np.linalg.norm(los_vector)

        if los_distance < 10:
            self.intercepted = True
            self.intercept_point = missile_pos.copy()
            return

        # Predict future missile position
        predicted_missile_pos = missile_pos + self.target.velocity_vector * 0.2  

        # Adjust movement toward predicted position
        new_direction = predicted_missile_pos - self.position
        new_direction /= np.linalg.norm(new_direction)  

        # Move the anti-missile
        step_distance = new_direction * self.velocity * 0.2  
        self.position += step_distance
        self.path.append(self.position.copy())

    def get_state(self):
        return self.position.copy()
    
def run_simulation(max_steps, show_plots=False, number_of_simulations=100):
    global missile_reached_goal, missile_intercepted

    for _ in range(number_of_simulations - 1):

        # Initialize the environment and entities
        env = MissileEnv()
        antimissile = AntiMissile(env)
        pomdp = POMDPPlanner(env, antimissile)

        env.reset()
        missile_traj = []
        antimissile_traj = []

        # Simulation update function
        simulation_ended = False
        steps = 0
        if not show_plots:
            while not simulation_ended:
                if not env.is_goal_reached() and not antimissile.intercepted:
                    observation = env.get_state() + np.random.normal(0, 2, 3)  # Simulated noisy observation
                    pomdp.update_belief(observation)
                    
                    best_action = pomdp.search()
                    env.step(best_action)
                    missile_traj.append(env.get_state())

                    antimissile.proportional_navigation()
                    antimissile_traj.append(antimissile.get_state())

                    # Compute distances
                    missile_to_goal_dist = np.linalg.norm(env.get_state() - env.goal)
                    missile_to_antimissile_dist = np.linalg.norm(env.get_state() - antimissile.get_state())

                    # Print distances at each step
                    # print(f"Missile-Goal Distance = {missile_to_goal_dist:.2f}, "
                    #       f"Missile-AntiMissile Distance = {missile_to_antimissile_dist:.2f}")
                    if steps > max_steps:
                        print("❌ Simulation ended due to max steps reached")
                        break
                    steps += 1

                else:
                    missile_to_goal_dist = np.linalg.norm(env.get_state() - env.goal)
                    missile_to_antimissile_dist = np.linalg.norm(env.get_state() - antimissile.get_state())

                    print("\n--- Simulation Ended ---")
                    if env.is_goal_reached():
                        print("✅ Missile reached the goal!")
                        missile_reached_goal += 1
                    elif antimissile.intercepted:
                        print("❌ Anti-Missile intercepted the missile!")
                        missile_intercepted += 1

                    # print(f"Final Missile-Goal Distance: {missile_to_goal_dist:.2f}")
                    # print(f"Final Missile-AntiMissile Distance: {missile_to_antimissile_dist:.2f}")

                    simulation_ended = True
        else:
            def update(frame):
                global missile_reached_goal, missile_intercepted

                simulation_ended = False

                if not simulation_ended:
                    if not env.is_goal_reached() and not antimissile.intercepted:
                        observation = env.get_state() + np.random.normal(0, 2, 3)  # Simulated noisy observation
                        pomdp.update_belief(observation)
                        
                        best_action = pomdp.search()
                        env.step(best_action)
                        missile_traj.append(env.get_state())

                        antimissile.proportional_navigation()
                        antimissile_traj.append(antimissile.get_state())

                        # Compute distances
                        missile_to_goal_dist = np.linalg.norm(env.get_state() - env.goal)
                        missile_to_antimissile_dist = np.linalg.norm(env.get_state() - antimissile.get_state())

                        # Print distances at each step
                        print(f"Frame {frame}: Missile-Goal Distance = {missile_to_goal_dist:.2f}, "
                            f"Missile-AntiMissile Distance = {missile_to_antimissile_dist:.2f}")

                    else:
                        missile_to_goal_dist = np.linalg.norm(env.get_state() - env.goal)
                        missile_to_antimissile_dist = np.linalg.norm(env.get_state() - antimissile.get_state())

                        print("\n--- Simulation Ended ---")
                        if env.is_goal_reached():
                            print("✅ Missile reached the goal!")
                            missile_reached_goal += 1
                            plt.close()
                        elif antimissile.intercepted:
                            print("❌ Anti-Missile intercepted the missile!")
                            missile_intercepted += 1
                            plt.close()

                        print(f"Final Missile-Goal Distance: {missile_to_goal_dist:.2f}")
                        print(f"Final Missile-AntiMissile Distance: {missile_to_antimissile_dist:.2f}")

                        simulation_ended = True

                ax.clear()
                ax.set_xlim(0, env.bounds[0])
                ax.set_ylim(0, env.bounds[1])
                ax.set_zlim(0, env.bounds[2])
                ax.scatter(*env.goal, color='red', s=100, label='Goal')
                ax.scatter(*env.get_state(), color='blue', s=150, label='Missile')
                ax.scatter(*antimissile.get_state(), color='green', s=150, label='Anti-Missile')

                if len(missile_traj) > 1:
                    missile_path = np.array(missile_traj)
                    ax.plot(missile_path[:, 0], missile_path[:, 1], missile_path[:, 2], color='blue', linestyle='solid', label='Missile Trajectory')

                if len(antimissile_traj) > 1:
                    antimissile_path = np.array(antimissile_traj)
                    ax.plot(antimissile_path[:, 0], antimissile_path[:, 1], antimissile_path[:, 2], color='green', linestyle='solid', label='Anti-Missile Trajectory')

                if antimissile.intercepted:
                    ax.scatter(*antimissile.intercept_point, color='green', marker='X', s=200, label='Collision')

                if env.is_goal_reached():
                    ax.scatter(*env.goal, color='red', marker='X', s=200, label='Goal Reached')

                ax.legend()

            fig = plt.figure()
            ax = fig.add_subplot(111, projection='3d')

            def animate():
                ani = FuncAnimation(fig, update, frames=100, interval=200, blit=False)
                plt.show()

            animate()

if __name__ == "__main__":
    results = run_simulation(max_steps=max_steps, show_plots=show_plots, number_of_simulations=number_of_simulations)

    print(f"\nSimulation Results for POMDP planner:")
    print(f"Missile reached goal in {missile_reached_goal} out of 100 simulations")
    print(f"Missile intercepted in {missile_intercepted} out of 100 simulations")
    print(f"Number of simulations that reached max steps: {number_of_simulations - missile_reached_goal - missile_intercepted}")

    print(f"Missile Success Rate: {round(missile_reached_goal/number_of_simulations *100)}% and Anti-Missile Success Rate: {round((number_of_simulations - missile_reached_goal)/number_of_simulations * 100)}%\n")